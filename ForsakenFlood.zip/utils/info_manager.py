# bot/utils/info_manager.py
import json
from datetime import datetime
from typing import List, Dict, Optional
from aiogram import Bot
from database import (
    get_flood_roles, get_staff_roles, get_active_rests, 
    get_user, get_setting, set_setting
)
from config import config

class InfoManager:
    """
    Управление сообщениями в Info канале
    """
    
    def __init__(self, bot: Bot):
        self.bot = bot
        self.channel_id = config.INFO_CHANNEL_ID
        
        # ID сообщений (хранятся в БД или конфиге)
        self.roles_msg_id = None  # Сообщение с ролями флуда
        self.staff_msg_id = None  # Сообщение со стаффом
        self.rest_msg_id = None   # Сообщение с рестами
        self.status_msg_id = None # Сообщение со статусом набора
        
        # Загружаем ID сообщений
        asyncio.create_task(self._load_message_ids())
    
    async def _load_message_ids(self):
        """Загружает ID сообщений из БД"""
        self.roles_msg_id = await get_setting('info_roles_msg_id')
        self.staff_msg_id = await get_setting('info_staff_msg_id')
        self.rest_msg_id = await get_setting('info_rest_msg_id')
        self.status_msg_id = await get_setting('info_status_msg_id')
        
        # Если сообщений нет - создаем
        if not self.roles_msg_id:
            await self.create_info_messages()
    
    # ============ СОЗДАНИЕ СООБЩЕНИЙ ============
    
    async def create_info_messages(self):
        """Создает все сообщения в Info канале"""
        try:
            # 1. Сообщение с ролями флуда
            roles_text = await self._generate_roles_text()
            msg = await self.bot.send_message(
                chat_id=self.channel_id,
                text=roles_text,
                parse_mode="HTML"
            )
            self.roles_msg_id = msg.message_id
            await set_setting('info_roles_msg_id', str(msg.message_id))
            
            # 2. Сообщение со стаффом
            staff_text = await self._generate_staff_text()
            msg = await self.bot.send_message(
                chat_id=self.channel_id,
                text=staff_text,
                parse_mode="HTML"
            )
            self.staff_msg_id = msg.message_id
            await set_setting('info_staff_msg_id', str(msg.message_id))
            
            # 3. Сообщение с рестами
            rest_text = await self._generate_rest_text()
            msg = await self.bot.send_message(
                chat_id=self.channel_id,
                text=rest_text,
                parse_mode="HTML"
            )
            self.rest_msg_id = msg.message_id
            await set_setting('info_rest_msg_id', str(msg.message_id))
            
            # 4. Сообщение со статусом набора
            status_text = await self._generate_status_text()
            msg = await self.bot.send_message(
                chat_id=self.channel_id,
                text=status_text,
                parse_mode="HTML"
            )
            self.status_msg_id = msg.message_id
            await set_setting('info_status_msg_id', str(msg.message_id))
            
        except Exception as e:
            print(f"[INFO MANAGER] Ошибка создания сообщений: {e}")
    
    # ============ ГЕНЕРАЦИЯ ТЕКСТА ============
    
    async def _generate_roles_text(self) -> str:
        """Генерирует текст с ролями флуда"""
        roles = await get_flood_roles()
        text = "🌸 <b>РОЛИ ВО ФЛУДЕ</b>\n"
        text += "━━━━━━━━━━━━━━━━━━━\n\n"
        
        # Считаем количество людей в каждой роли
        from database import get_all_users_with_roles  # добавим позже
        
        for role in roles:
            count = await self._get_role_count(role)
            emoji = self._get_progress_emoji(count)
            text += f"<b>{role}:</b> {count}/5 {emoji}\n"
        
        text += "\n━━━━━━━━━━━━━━━━━━━\n"
        text += f"📢 <b>Набор:</b> {await self._get_flood_status()}"
        
        return text
    
    async def _generate_staff_text(self) -> str:
        """Генерирует текст со стаффом"""
        staff_roles = await get_staff_roles()
        text = "👔 <b>СТАФФ</b>\n"
        text += "━━━━━━━━━━━━━━━━━━━\n\n"
        
        for role in staff_roles:
            count = await self._get_staff_count(role)
            emoji = self._get_staff_progress_emoji(count)
            text += f"<b>{role}:</b> {count}/5 {emoji}\n"
        
        return text
    
    async def _generate_rest_text(self) -> str:
        """Генерирует текст с активными рестами"""
        rests = await get_active_rests()
        text = "⏰ <b>АКТИВНЫЕ РЕСТЫ</b>\n"
        text += "━━━━━━━━━━━━━━━━━━━\n\n"
        
        if not rests:
            text += "Нет активных рестов 🌿"
        else:
            for rest in rests:
                user = await get_user(rest['user_id'])
                if user:
                    username = user.get('username', 'Unknown')
                    end_date = datetime.fromisoformat(rest['end_date'])
                    days_left = (end_date - datetime.now()).days
                    text += f"👤 @{username}: <b>{days_left} дней</b>\n"
        
        return text
    
    async def _generate_status_text(self) -> str:
        """Генерирует текст со статусом набора"""
        is_open = await get_setting('flood_open') == '1'
        status = "🟢 ОТКРЫТ" if is_open else "🔴 ЗАКРЫТ"
        return f"📢 <b>СТАТУС НАБОРА</b>\n━━━━━━━━━━━━━━━━━━━\n\n{status}"
    
    # ============ ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ============
    
    async def _get_role_count(self, role: str) -> int:
        """Считает количество пользователей с данной ролью во флуде"""
        from database import get_users_by_flood_role
        users = await get_users_by_flood_role(role)
        return len(users)
    
    async def _get_staff_count(self, role: str) -> int:
        """Считает количество пользователей с данной ролью в стаффе"""
        from database import get_users_by_staff_role
        users = await get_users_by_staff_role(role)
        return len(users)
    
    def _get_progress_emoji(self, count: int) -> str:
        """Возвращает эмодзи прогресса для ролей флуда"""
        emojis = {
            0: '🌸',
            1: '🌸',
            2: '💐',
            3: '💐',
            4: '💐',
            5: '💐'
        }
        return emojis.get(count, '🌸')
    
    def _get_staff_progress_emoji(self, count: int) -> str:
        """Возвращает эмодзи прогресса для стаффа"""
        emojis = {
            0: '⚫️',
            1: '🔴',
            2: '🟠',
            3: '🟡',
            4: '🔵',
            5: '🟢'
        }
        return emojis.get(count, '⚫️')
    
    async def _get_flood_status(self) -> str:
        """Возвращает статус набора"""
        is_open = await get_setting('flood_open') == '1'
        return "🟢 ОТКРЫТ" if is_open else "🔴 ЗАКРЫТ"
    
    # ============ ОБНОВЛЕНИЕ СООБЩЕНИЙ ============
    
    async def update_roles(self):
        """Обновляет сообщение с ролями"""
        if self.roles_msg_id:
            text = await self._generate_roles_text()
            try:
                await self.bot.edit_message_text(
                    chat_id=self.channel_id,
                    message_id=int(self.roles_msg_id),
                    text=text,
                    parse_mode="HTML"
                )
            except Exception as e:
                print(f"[INFO MANAGER] Ошибка обновления ролей: {e}")
    
    async def update_staff(self):
        """Обновляет сообщение со стаффом"""
        if self.staff_msg_id:
            text = await self._generate_staff_text()
            try:
                await self.bot.edit_message_text(
                    chat_id=self.channel_id,
                    message_id=int(self.staff_msg_id),
                    text=text,
                    parse_mode="HTML"
                )
            except Exception as e:
                print(f"[INFO MANAGER] Ошибка обновления стаффа: {e}")
    
    async def update_rests(self):
        """Обновляет сообщение с рестами"""
        if self.rest_msg_id:
            text = await self._generate_rest_text()
            try:
                await self.bot.edit_message_text(
                    chat_id=self.channel_id,
                    message_id=int(self.rest_msg_id),
                    text=text,
                    parse_mode="HTML"
                )
            except Exception as e:
                print(f"[INFO MANAGER] Ошибка обновления рестов: {e}")
    
    async def update_status(self):
        """Обновляет сообщение со статусом"""
        if self.status_msg_id:
            text = await self._generate_status_text()
            try:
                await self.bot.edit_message_text(
                    chat_id=self.channel_id,
                    message_id=int(self.status_msg_id),
                    text=text,
                    parse_mode="HTML"
                )
            except Exception as e:
                print(f"[INFO MANAGER] Ошибка обновления статуса: {e}")
    
    async def update_all(self):
        """Обновляет все сообщения"""
        await self.update_roles()
        await self.update_staff()
        await self.update_rests()
        await self.update_status()
    
    # ============ УДАЛЕНИЕ РОЛИ ============
    
    async def remove_flood_role(self, role: str) -> bool:
        """Удаляет роль флуда и обновляет всех пользователей"""
        roles = await get_flood_roles()
        
        if role not in roles:
            return False
        
        # Удаляем роль из списка
        roles.remove(role)
        await set_setting('flood_roles', json.dumps(roles, ensure_ascii=False))
        
        # Убираем роль у всех пользователей
        from database import remove_flood_role_from_users
        await remove_flood_role_from_users(role)
        
        # Обновляем сообщения
        await self.update_roles()
        
        return True
    
    async def remove_staff_role(self, role: str) -> bool:
        """Удаляет роль стаффа и обновляет всех пользователей"""
        roles = await get_staff_roles()
        
        if role not in roles:
            return False
        
        # Удаляем роль из списка
        roles.remove(role)
        await set_setting('staff_roles', json.dumps(roles, ensure_ascii=False))
        
        # Убираем роль у всех пользователей
        from database import remove_staff_role_from_users
        await remove_staff_role_from_users(role)
        
        # Обновляем сообщения
        await self.update_staff()
        
        return True
    
    # ============ УДАЛЕНИЕ АДМИНА ============
    
    async def remove_admin(self, user_id: int) -> bool:
        """Удаляет админа и обновляет все"""
        from database import update_user_role, get_user_role
        
        role = await get_user_role(user_id)
        if role != 'админ':
            return False
        
        # Меняем роль на участника
        await update_user_role(user_id, 'участник')
        
        # Логируем
        from utils.logger import Logger
        # ... логика логирования
        
        return True
    
    # ============ ОЧИСТКА КАНАЛА ============
    
    async def clear_all_messages(self):
        """Удаляет все сообщения бота в канале (только свои)"""
        try:
            # Удаляем сообщения бота
            msg_ids = [
                self.roles_msg_id,
                self.staff_msg_id,
                self.rest_msg_id,
                self.status_msg_id
            ]
            
            for msg_id in msg_ids:
                if msg_id:
                    try:
                        await self.bot.delete_message(
                            chat_id=self.channel_id,
                            message_id=int(msg_id)
                        )
                    except:
                        pass
            
            # Сбрасываем ID
            self.roles_msg_id = None
            self.staff_msg_id = None
            self.rest_msg_id = None
            self.status_msg_id = None
            
            await set_setting('info_roles_msg_id', '')
            await set_setting('info_staff_msg_id', '')
            await set_setting('info_rest_msg_id', '')
            await set_setting('info_status_msg_id', '')
            
            # Создаем заново
            await self.create_info_messages()
            
            return True
        except Exception as e:
            print(f"[INFO MANAGER] Ошибка очистки: {e}")
            return False

# bot/utils/info_manager.py (дополняем)
from config import config

class InfoManager:
    def __init__(self, bot: Bot):
        self.bot = bot
        self.channel_id = config.INFO_CHANNEL_ID  # Берем из конфига
        
        # Ссылка на канал
        self.channel_link = config.INFO_CHANNEL_LINK
        
        # ID сообщений (из конфига или БД)
        self.roles_msg_id = config.INFO_ROLES_MSG_ID
        self.staff_msg_id = config.INFO_STAFF_MSG_ID
        self.rest_msg_id = config.INFO_REST_MSG_ID
        self.status_msg_id = config.INFO_STATUS_MSG_ID
        
        # Загружаем ID из БД, если они есть
        asyncio.create_task(self._load_message_ids())
    
    async def _load_message_ids(self):
        """Загружает ID сообщений из БД"""
        self.roles_msg_id = await get_setting('info_roles_msg_id') or config.INFO_ROLES_MSG_ID
        self.staff_msg_id = await get_setting('info_staff_msg_id') or config.INFO_STAFF_MSG_ID
        self.rest_msg_id = await get_setting('info_rest_msg_id') or config.INFO_REST_MSG_ID
        self.status_msg_id = await get_setting('info_status_msg_id') or config.INFO_STATUS_MSG_ID
        
        if not self.roles_msg_id:
            await self.create_info_messages()