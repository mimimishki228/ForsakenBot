# bot/utils/logger.py
import asyncio
from datetime import datetime
from typing import Dict, Any
from aiogram import Bot, types
from database import add_log

class Logger:
    """Система логирования в канал для владельцев"""
    
    def __init__(self, bot: Bot, channel_id: int):
        self.bot = bot
        self.channel_id = channel_id
        self.log_queue = asyncio.Queue()
        self.is_running = True
        asyncio.create_task(self._process_queue())
    
    async def _process_queue(self):
        """Обрабатывает очередь логов"""
        while self.is_running:
            try:
                log_data = await self.log_queue.get()
                await self._send_log(log_data)
            except Exception as e:
                print(f"[LOGGER ERROR] {e}")
    
    async def _send_log(self, data: Dict[str, Any]):
        """Отправляет лог в канал"""
        try:
            msg = self._format_log(data)
            await self.bot.send_message(
                chat_id=self.channel_id,
                text=msg,
                parse_mode="HTML"
            )
            # Сохраняем в БД
            user_id = data.get('user', {}).get('id')
            if user_id:
                await add_log(user_id, data.get('action', ''), data.get('details', ''))
        except Exception as e:
            print(f"[LOGGER SEND ERROR] {e}")
    
    def _format_log(self, data: Dict[str, Any]) -> str:
        """Форматирует лог"""
        log_type = data.get('type', 'INFO')
        timestamp = data.get('timestamp', datetime.now())
        user = data.get('user', {})
        action = data.get('action', '')
        details = data.get('details', '')
        
        emojis = {
            'INFO': 'ℹ️', 'WARNING': '⚠️', 'ERROR': '❌',
            'SUCCESS': '✅', 'ACTION': '🔄', 'BAN': '🔨',
            'UNBAN': '🔓', 'FLOOD_ACCEPT': '🌊', 'STAFF_ACCEPT': '👔',
            'REST_ACCEPT': '⏰', 'ADMIN_ADD': '➕', 'ADMIN_REMOVE': '➖',
            'OWNER_ACTION': '👑'
        }
        
        emoji = emojis.get(log_type, '📝')
        
        msg = f"<b>{emoji} {log_type}</b>\n"
        msg += f"🕐 <b>Время:</b> <code>{timestamp.strftime('%Y-%m-%d %H:%M:%S')}</code>\n"
        
        if user:
            msg += f"👤 <b>Пользователь:</b> "
            if user.get('username'):
                msg += f"@{user['username']} "
            msg += f"<code>ID: {user.get('id', 'Unknown')}</code>\n"
        
        if action:
            msg += f"📌 <b>Действие:</b> {action}\n"
        
        if details:
            msg += f"📝 <b>Подробности:</b>\n<code>{details}</code>\n"
        
        return msg
    
    # ============ МЕТОДЫ ЛОГГИРОВАНИЯ ============
    
    async def log_start(self, user: types.User):
        await self.log_queue.put({
            'type': 'INFO',
            'timestamp': datetime.now(),
            'user': {'id': user.id, 'username': user.username},
            'action': 'Запуск бота',
            'details': f"Пользователь {user.full_name} запустил бота"
        })
    
    async def log_flood_application(self, user: types.User, form_data: dict):
        await self.log_queue.put({
            'type': 'INFO',
            'timestamp': datetime.now(),
            'user': {'id': user.id, 'username': user.username},
            'action': 'Подана заявка во флуд',
            'details': f"Анкета: {form_data}"
        })
    
    async def log_flood_accept(self, user: types.User, admin: types.User, role: str):
        await self.log_queue.put({
            'type': 'FLOOD_ACCEPT',
            'timestamp': datetime.now(),
            'user': {'id': user.id, 'username': user.username},
            'action': f'Принят во флуд (роль: {role})',
            'details': f"Админ: @{admin.username} (ID: {admin.id})"
        })
    
    # Добавьте остальные методы логирования аналогично

# bot/utils/logger.py (дополняем)

async def log_add_admin(self, owner: types.User, new_admin: types.User):
    """Логирует добавление админа"""
    await self.log_queue.put({
        'type': 'ADMIN_ADD',
        'timestamp': datetime.now(),
        'user': {'id': new_admin.id, 'username': new_admin.username},
        'action': 'Назначен админом',
        'details': f"Владелец: @{owner.username} (ID: {owner.id})"
    })

async def log_remove_admin(self, owner: types.User, admin: types.User):
    """Логирует удаление админа"""
    await self.log_queue.put({
        'type': 'ADMIN_REMOVE',
        'timestamp': datetime.now(),
        'user': {'id': admin.id, 'username': admin.username},
        'action': 'Лишен прав админа',
        'details': f"Владелец: @{owner.username} (ID: {owner.id})"
    })

async def log_owner_action(self, owner: types.User, action: str, details: str = ''):
    """Логирует действие владельца"""
    await self.log_queue.put({
        'type': 'OWNER_ACTION',
        'timestamp': datetime.now(),
        'user': {'id': owner.id, 'username': owner.username},
        'action': action,
        'details': details
    })

async def log_config_change(self, owner: types.User, config_type: str, old_data: dict, new_data: dict):
    """Логирует изменение конфига"""
    import json
    await self.log_queue.put({
        'type': 'OWNER_ACTION',
        'timestamp': datetime.now(),
        'user': {'id': owner.id, 'username': owner.username},
        'action': f'Изменен конфиг: {config_type}',
        'details': f"Было:\n{json.dumps(old_data, indent=2, ensure_ascii=False)}\n\nСтало:\n{json.dumps(new_data, indent=2, ensure_ascii=False)}"
    })

async def log_role_removed(self, owner: types.User, role_type: str, role: str):
    """Логирует удаление роли"""
    await self.log_queue.put({
        'type': 'OWNER_ACTION',
        'timestamp': datetime.now(),
        'user': {'id': owner.id, 'username': owner.username},
        'action': f'Удалена роль {role_type}',
        'details': f"Роль: {role}"
    })

# bot/utils/logger.py (дополняем)

async def log_staff_application(self, user: types.User, form_data: dict):
    """Логирует подачу заявки в стафф"""
    await self.log_queue.put({
        'type': 'INFO',
        'timestamp': datetime.now(),
        'user': {'id': user.id, 'username': user.username},
        'action': 'Подана заявка в стафф',
        'details': f"Анкета: {form_data}"
    })

async def log_staff_accept(self, user: types.User, admin: types.User, role: str):
    """Логирует принятие в стафф"""
    await self.log_queue.put({
        'type': 'STAFF_ACCEPT',
        'timestamp': datetime.now(),
        'user': {'id': user.id, 'username': user.username},
        'action': f'Принят в стафф (роль: {role})',
        'details': f"Админ: @{admin.username} (ID: {admin.id})"
    })

async def log_staff_reject(self, user: types.User, admin: types.User):
    """Логирует отклонение из стаффа"""
    await self.log_queue.put({
        'type': 'WARNING',
        'timestamp': datetime.now(),
        'user': {'id': user.id, 'username': user.username},
        'action': 'Отклонен из стаффа',
        'details': f"Админ: @{admin.username} (ID: {admin.id})"
    })