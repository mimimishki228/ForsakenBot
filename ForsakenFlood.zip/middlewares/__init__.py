# bot/middlewares/__init__.py
# Middleware для защиты от спама