# bot/handlers/flood.py
import json
from aiogram import Router, F, types
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.filters import StateFilter

from database import (
    create_user, get_user, update_user_role, 
    create_application, get_pending_applications,
    get_application, update_application_status,
    is_flood_open, is_banned, get_flood_roles,
    get_user_role, set_setting
)
from keyboards import (
    get_flood_menu, get_back_button, get_cancel_button,
    get_application_action_buttons, get_applications_menu,
    get_main_menu
)
from utils.info_manager import InfoManager
from utils.logger import Logger
from config import config

router = Router()

# ============ FSM ДЛЯ АНКЕТЫ ============

class FloodApplicationStates(StatesGroup):
    waiting_for_name = State()
    waiting_for_age = State()
    waiting_for_experience = State()
    waiting_for_reason = State()
    waiting_for_confirm = State()

# ============ ЗАЯВКА ВО ФЛУД ============

@router.callback_query(F.data == "flood_apply")
async def flood_apply(call: CallbackQuery, state: FSMContext):
    """Начинает процесс подачи заявки во флуд"""
    user_id = call.from_user.id
    
    # Проверяем бан
    if await is_banned(user_id):
        await call.answer("🚫 Вы забанены!", show_alert=True)
        return
    
    # Проверяем, открыт ли набор
    if not await is_flood_open():
        await call.answer("❌ Набор во флуд закрыт!", show_alert=True)
        return
    
    # Проверяем, не состоит ли уже во флуде
    user = await get_user(user_id)
    if user and user.get('is_flood_member'):
        await call.answer("✅ Вы уже во флуде!", show_alert=True)
        return
    
    await call.message.edit_text(
        "🌊 <b>Заявка во флуд</b>\n\n"
        "Давайте заполним анкету.\n"
        "Отвечайте на вопросы.\n\n"
        "Для отмены нажмите кнопку ниже.",
        reply_markup=get_cancel_button(),
        parse_mode="HTML"
    )
    
    # Задаем первый вопрос
    await call.message.answer(
        "📝 <b>Вопрос 1:</b>\n"
        "Как вас называть? (Имя или ник)",
        parse_mode="HTML"
    )
    
    await state.set_state(FloodApplicationStates.waiting_for_name)
    await call.answer()

@router.message(FloodApplicationStates.waiting_for_name)
async def process_flood_name(message: Message, state: FSMContext):
    """Обрабатывает имя"""
    await state.update_data(name=message.text)
    
    await message.answer(
        "📝 <b>Вопрос 2:</b>\n"
        "Сколько вам лет?",
        parse_mode="HTML"
    )
    
    await state.set_state(FloodApplicationStates.waiting_for_age)

@router.message(FloodApplicationStates.waiting_for_age)
async def process_flood_age(message: Message, state: FSMContext):
    """Обрабатывает возраст"""
    if not message.text.isdigit():
        await message.answer("❌ Введите число!")
        return
    
    await state.update_data(age=int(message.text))
    
    await message.answer(
        "📝 <b>Вопрос 3:</b>\n"
        "Какой у вас опыт в подобных проектах?",
        parse_mode="HTML"
    )
    
    await state.set_state(FloodApplicationStates.waiting_for_experience)

@router.message(FloodApplicationStates.waiting_for_experience)
async def process_flood_experience(message: Message, state: FSMContext):
    """Обрабатывает опыт"""
    await state.update_data(experience=message.text)
    
    await message.answer(
        "📝 <b>Вопрос 4:</b>\n"
        "Почему вы хотите попасть во флуд?",
        parse_mode="HTML"
    )
    
    await state.set_state(FloodApplicationStates.waiting_for_reason)

@router.message(FloodApplicationStates.waiting_for_reason)
async def process_flood_reason(message: Message, state: FSMContext):
    """Обрабатывает причину"""
    await state.update_data(reason=message.text)
    
    # Получаем все данные
    data = await state.get_data()
    
    # Формируем анкету
    form_data = {
        'name': data.get('name'),
        'age': data.get('age'),
        'experience': data.get('experience'),
        'reason': data.get('reason'),
        'username': message.from_user.username,
        'full_name': message.from_user.full_name
    }
    
    # Показываем анкету для подтверждения
    text = (
        "📋 <b>Проверьте анкету:</b>\n\n"
        f"👤 Имя: {form_data['name']}\n"
        f"🎂 Возраст: {form_data['age']}\n"
        f"💪 Опыт: {form_data['experience']}\n"
        f"❓ Причина: {form_data['reason']}\n\n"
        "Все верно?"
    )
    
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅ Да", callback_data="flood_confirm"),
                InlineKeyboardButton("❌ Нет, заново", callback_data="flood_restart")
            ]
        ]
    )
    
    await message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    await state.set_state(FloodApplicationStates.waiting_for_confirm)
    
    # Сохраняем данные в state
    await state.update_data(form_data=form_data)

@router.callback_query(F.data == "flood_confirm")
async def flood_confirm(call: CallbackQuery, state: FSMContext):
    """Подтверждение анкеты"""
    user_id = call.from_user.id
    data = await state.get_data()
    form_data = data.get('form_data')
    
    if not form_data:
        await call.answer("❌ Ошибка! Попробуйте заново.", show_alert=True)
        await state.clear()
        return
    
    # Создаем заявку в БД
    app_id = await create_application(user_id, 'flood', form_data)
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_flood_application(call.from_user, form_data)
    
    # Отправляем уведомление админам
    await notify_admins_about_application(call.bot, app_id, form_data, call.from_user)
    
    await call.message.edit_text(
        "✅ <b>Заявка отправлена!</b>\n\n"
        "Ожидайте ответа админов.",
        reply_markup=get_back_button("back_to_flood"),
        parse_mode="HTML"
    )
    await state.clear()
    await call.answer()

@router.callback_query(F.data == "flood_restart")
async def flood_restart(call: CallbackQuery, state: FSMContext):
    """Перезапуск анкеты"""
    await state.clear()
    await call.message.edit_text(
        "🔄 Начинаем заново...",
        reply_markup=get_back_button("back_to_flood")
    )
    await call.answer()

# ============ УВЕДОМЛЕНИЕ АДМИНОВ ============

async def notify_admins_about_application(bot, app_id: int, form_data: dict, user: types.User):
    """Отправляет уведомление админам о новой заявке"""
    from database import get_all_admins
    
    text = (
        f"📋 <b>НОВАЯ ЗАЯВКА ВО ФЛУД!</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"🆔 Заявка #<b>{app_id}</b>\n"
        f"👤 От: @{user.username} (ID: {user.id})\n\n"
        f"<b>Анкета:</b>\n"
        f"Имя: {form_data.get('name')}\n"
        f"Возраст: {form_data.get('age')}\n"
        f"Опыт: {form_data.get('experience')}\n"
        f"Причина: {form_data.get('reason')}\n\n"
        f"Чтобы ответить, напишите под этим сообщением:\n"
        f"<code>Принять,Роль</code> или <code>Отклонено</code>"
    )
    
    # Получаем всех админов и владельцев
    admins = await get_all_admins()
    owner_ids = config.OWNER_IDS
    
    # Отправляем каждому админу и владельцу
    for admin in admins:
        if admin['user_id'] in owner_ids or admin['role'] in ['админ', 'владелец']:
            try:
                sent_msg = await bot.send_message(
                    chat_id=admin['user_id'],
                    text=text,
                    parse_mode="HTML"
                )
                # Сохраняем ID сообщения для ответа
                await save_application_message(app_id, admin['user_id'], sent_msg.message_id)
            except Exception as e:
                print(f"Не удалось отправить админу {admin['user_id']}: {e}")
    
    # Также отправляем в канал логов
    logger: Logger = bot.data.get('logger')
    await logger.log_flood_application(user, form_data)

# ============ ОБРАБОТКА ОТВЕТОВ АДМИНОВ ============

@router.message()
async def handle_admin_reply(message: Message, state: FSMContext):
    """Обрабатывает ответы админов на заявки"""
    user_id = message.from_user.id
    
    # Проверяем, что это админ или владелец
    role = await get_user_role(user_id)
    if role not in ['админ', 'владелец']:
        return
    
    # Проверяем, что это ответ на сообщение бота
    if not message.reply_to_message:
        return
    
    if message.reply_to_message.from_user.id != message.bot.id:
        return
    
    # Проверяем, что в сообщении есть ID заявки
    original_text = message.reply_to_message.text
    if "Заявка #" not in original_text and "ЗАЯВКА" not in original_text:
        return
    
    # Ищем ID заявки в тексте
    import re
    match = re.search(r'#(\d+)', original_text)
    if not match:
        return
    
    app_id = int(match.group(1))
    
    # Получаем заявку
    application = await get_application(app_id)
    if not application or application['status'] != 'pending':
        await message.answer("❌ Заявка уже обработана!")
        return
    
    # Парсим ответ
    text = message.text.strip()
    
    if text.lower().startswith('принять'):
        # Формат: "Принять,Роль"
        parts = text.split(',')
        if len(parts) < 2:
            await message.answer(
                "❌ Неверный формат!\n"
                "Используйте: <code>Принять,Роль</code>",
                parse_mode="HTML"
            )
            return
        
        role = parts[1].strip()
        
        # Проверяем, что роль существует
        roles = await get_flood_roles()
        if role not in roles:
            await message.answer(
                f"❌ Роль <b>{role}</b> не найдена!\n"
                f"Доступные роли: {', '.join(roles)}",
                parse_mode="HTML"
            )
            return
        
        # Принимаем заявку
        await accept_flood_application(app_id, user_id, role, message)
        
    elif text.lower() == 'отклонено':
        # Отклоняем заявку
        await reject_flood_application(app_id, user_id, message)
        
    else:
        await message.answer(
            "❌ Неверная команда!\n"
            "Используйте: <code>Принять,Роль</code> или <code>Отклонено</code>",
            parse_mode="HTML"
        )

# ============ ПРИНЯТИЕ ЗАЯВКИ ============

async def accept_flood_application(app_id: int, admin_id: int, role: str, message: Message):
    """Принимает заявку во флуд"""
    application = await get_application(app_id)
    if not application:
        return
    
    user_id = application['user_id']
    
    # Обновляем статус заявки
    await update_application_status(app_id, 'accepted', admin_id, f'Принят с ролью: {role}')
    
    # Обновляем роль пользователя
    await update_user_role(user_id, 'участник')  # или оставляем участником
    await set_user_flood_role(user_id, role)
    await set_user_flood_member(user_id, True)
    
    # Отправляем пользователю ссылку на группу
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text=(
                f"✅ <b>Поздравляем! Вы приняты во флуд!</b>\n\n"
                f"🌸 Ваша роль: <b>{role}</b>\n"
                f"🔗 Ссылка на группу: {config.FLOOD_GROUP_LINK}\n\n"
                f"Нажмите кнопку ниже, чтобы перейти:"
            ),
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton("🌊 Перейти во флуд", url=config.FLOOD_GROUP_LINK)]
                ]
            ),
            parse_mode="HTML"
        )
        
        # Отправляем приветствие в группу
        await message.bot.send_message(
            chat_id=config.FLOOD_GROUP_ID,
            text=f"🌊 <b>Новый участник!</b>\n\n"
                 f"👤 @{message.from_user.username}\n"
                 f"🌸 Роль: {role}\n\n"
                 f"<b>Калл нью {role}!</b>",
            parse_mode="HTML"
        )
        
    except Exception as e:
        print(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
    
    # Обновляем Info канал
    info_manager: InfoManager = message.bot.data.get('info_manager')
    await info_manager.update_roles()
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    admin_user = await get_user(admin_id)
    user = await get_user(user_id)
    await logger.log_flood_accept(
        user=types.User(id=user_id, username=user.get('username'), full_name=user.get('full_name')),
        admin=types.User(id=admin_id, username=admin_user.get('username'), full_name=admin_user.get('full_name')),
        role=role
    )
    
    await message.answer(
        f"✅ Заявка #<b>{app_id}</b> принята!\n"
        f"🌸 Роль: {role}\n"
        f"👤 Пользователь: @{user.get('username', user_id)}",
        parse_mode="HTML"
    )

# ============ ОТКЛОНЕНИЕ ЗАЯВКИ ============

async def reject_flood_application(app_id: int, admin_id: int, message: Message):
    """Отклоняет заявку во флуд"""
    application = await get_application(app_id)
    if not application:
        return
    
    user_id = application['user_id']
    
    # Обновляем статус заявки
    await update_application_status(app_id, 'rejected', admin_id, 'Отклонено')
    
    # Отправляем уведомление пользователю
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text=(
                "❌ <b>Ваша заявка отклонена!</b>\n\n"
                "К сожалению, администрация приняла решение отклонить вашу заявку.\n"
                "Вы можете попробовать подать заявку снова позже.",
                parse_mode="HTML"
            )
        )
    except Exception as e:
        print(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    admin_user = await get_user(admin_id)
    user = await get_user(user_id)
    await logger.log_flood_reject(
        user=types.User(id=user_id, username=user.get('username'), full_name=user.get('full_name')),
        admin=types.User(id=admin_id, username=admin_user.get('username'), full_name=admin_user.get('full_name')),
        reason='Отклонено'
    )
    
    await message.answer(
        f"❌ Заявка #<b>{app_id}</b> отклонена!",
        parse_mode="HTML"
    )

# ============ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ============

async def set_user_flood_role(user_id: int, role: str):
    """Устанавливает роль пользователя во флуде"""
    from database import DB_PATH
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET flood_role = ? WHERE user_id = ?',
            (role, user_id)
        )
        await db.commit()

async def set_user_flood_member(user_id: int, is_member: bool):
    """Устанавливает статус участника флуда"""
    from database import DB_PATH
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET is_flood_member = ? WHERE user_id = ?',
            (1 if is_member else 0, user_id)
        )
        await db.commit()

async def save_application_message(app_id: int, admin_id: int, msg_id: int):
    """Сохраняет ID сообщения для ответа админа"""
    from database import DB_PATH
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('''
            CREATE TABLE IF NOT EXISTS app_messages (
                app_id INTEGER,
                admin_id INTEGER,
                msg_id INTEGER,
                PRIMARY KEY (app_id, admin_id)
            )
        ''')
        await db.execute(
            'INSERT OR REPLACE INTO app_messages (app_id, admin_id, msg_id) VALUES (?, ?, ?)',
            (app_id, admin_id, msg_id)
        )
        await db.commit()

# ============ НАЗАД В FLOOD МЕНЮ ============

@router.callback_query(F.data == "back_to_flood")
async def back_to_flood(call: CallbackQuery):
    """Возврат в меню Flood"""
    await call.message.edit_text(
        "🌊 Раздел Flood:\n\n"
        "Выберите действие:",
        reply_markup=await get_flood_menu(call.from_user.id)
    )
    await call.answer()

@router.callback_query(F.data == "cancel")
async def cancel_action(call: CallbackQuery, state: FSMContext):
    """Отмена действия"""
    await state.clear()
    await call.message.edit_text(
        "❌ Действие отменено.",
        reply_markup=await get_flood_menu(call.from_user.id)
    )
    await call.answer()