# bot/handlers/admin.py
import re
from aiogram import Router, F, types
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import (
    get_user, get_user_role, get_all_admins,
    update_user_role, is_admin, is_owner,
    get_pending_applications, get_application,
    update_application_status, set_setting,
    is_flood_open, get_user_by_username
)
from keyboards import get_admin_panel, get_back_button, get_applications_menu
from utils.info_manager import InfoManager
from utils.logger import Logger
from config import config

router = Router()

# ============ FSM ДЛЯ БАНА ============

class BanStates(StatesGroup):
    waiting_for_user = State()
    waiting_for_reason = State()

# ============ АДМИН ПАНЕЛЬ ============

@router.callback_query(F.data == "menu_admin")
async def menu_admin(call: CallbackQuery):
    """Открывает админ панель"""
    user_id = call.from_user.id
    
    if not await is_admin(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "⚙️ <b>Админ панель</b>\n\n"
        "Выберите действие:",
        reply_markup=await get_admin_panel(user_id),
        parse_mode="HTML"
    )
    await call.answer()

# ============ ЗАЯВКИ В АДМИН ПАНЕЛИ ============

@router.callback_query(F.data.startswith("admin_apps_"))
async def admin_applications(call: CallbackQuery):
    """Показывает список заявок"""
    user_id = call.from_user.id
    
    if not await is_admin(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    app_type = call.data.replace("admin_apps_", "")
    
    if app_type == "all":
        apps = await get_pending_applications()
        title = "📋 Все заявки"
    elif app_type == "flood":
        apps = await get_pending_applications('flood')
        title = "🌊 Заявки во флуд"
    elif app_type == "staff":
        apps = await get_pending_applications('staff')
        title = "👔 Заявки в стафф"
    elif app_type == "rest":
        apps = await get_pending_applications('rest')
        title = "⏰ Заявки на рест"
    else:
        await call.answer("❌ Неизвестный тип!")
        return
    
    if not apps:
        await call.message.edit_text(
            f"{title}\n\n📭 Нет новых заявок.",
            reply_markup=await get_applications_menu(app_type if app_type != "all" else None)
        )
        await call.answer()
        return
    
    # Показываем первую заявку
    app = apps[0]
    await show_application(call.message, app, len(apps), 0, title)
    await call.answer()

async def show_application(msg: Message, app: dict, total: int, index: int, title: str):
    """Показывает одну заявку"""
    user = await get_user(app['user_id'])
    form_data = app['form_data']
    
    text = (
        f"{title}\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"🆔 Заявка #{app['id']}\n"
        f"👤 От: @{user.get('username', app['user_id'])}\n"
        f"📅 Дата: {app['created_at']}\n\n"
        f"<b>Анкета:</b>\n"
    )
    
    for key, value in form_data.items():
        text += f"📌 {key}: {value}\n"
    
    text += f"\n📊 {index + 1}/{total}"
    
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅ Принять", callback_data=f"app_accept_{app['id']}"),
                InlineKeyboardButton("❌ Отклонить", callback_data=f"app_reject_{app['id']}")
            ],
            [
                InlineKeyboardButton("⬅️ Назад", callback_data=f"app_prev_{app['id']}_{index}"),
                InlineKeyboardButton("Вперед ➡️", callback_data=f"app_next_{app['id']}_{index}")
            ],
            [InlineKeyboardButton("🔙 Назад к списку", callback_data="admin_apps_back")]
        ]
    )
    
    await msg.edit_text(text, reply_markup=keyboard, parse_mode="HTML")

# ============ ДЕЙСТВИЯ С ЗАЯВКАМИ В АДМИН ПАНЕЛИ ============

@router.callback_query(F.data.startswith("app_accept_"))
async def app_accept(call: CallbackQuery):
    """Принимает заявку"""
    await call.answer("✅ Заявка принята! Теперь ответьте на сообщение бота с ролью.")
    # Логика в обработчике сообщений

@router.callback_query(F.data.startswith("app_reject_"))
async def app_reject(call: CallbackQuery):
    """Отклоняет заявку"""
    await call.answer("❌ Заявка отклонена!")
    # Логика в обработчике сообщений

# ============ ЗАКРЫТЬ/ОТКРЫТЬ НАБОР ============

@router.callback_query(F.data == "admin_close_flood")
async def admin_close_flood(call: CallbackQuery):
    """Закрывает набор во флуд"""
    user_id = call.from_user.id
    
    if not await is_admin(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await set_setting('flood_open', '0')
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_set_flood_closed(call.from_user)
    
    # Обновляем Info канал
    info_manager: InfoManager = call.bot.data.get('info_manager')
    await info_manager.update_status()
    
    await call.message.edit_text(
        "🔒 Набор во флуд <b>ЗАКРЫТ</b>!",
        reply_markup=await get_admin_panel(user_id),
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data == "admin_open_flood")
async def admin_open_flood(call: CallbackQuery):
    """Открывает набор во флуд"""
    user_id = call.from_user.id
    
    if not await is_admin(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await set_setting('flood_open', '1')
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_set_flood_open(call.from_user)
    
    # Обновляем Info канал
    info_manager: InfoManager = call.bot.data.get('info_manager')
    await info_manager.update_status()
    
    await call.message.edit_text(
        "🔓 Набор во флуд <b>ОТКРЫТ</b>!",
        reply_markup=await get_admin_panel(user_id),
        parse_mode="HTML"
    )
    await call.answer()

# ============ БАН ============

@router.callback_query(F.data == "admin_ban")
async def admin_ban_start(call: CallbackQuery, state: FSMContext):
    """Начинает процесс бана"""
    user_id = call.from_user.id
    
    if not await is_admin(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "🔨 <b>Бан пользователя</b>\n\n"
        "Отправьте ID пользователя или @username:\n"
        "Например: <code>123456789</code> или <code>@username</code>",
        reply_markup=get_back_button("back_to_admin"),
        parse_mode="HTML"
    )
    await state.set_state(BanStates.waiting_for_user)
    await call.answer()

@router.message(BanStates.waiting_for_user)
async def admin_ban_user(message: Message, state: FSMContext):
    """Обрабатывает ввод пользователя для бана"""
    admin_id = message.from_user.id
    
    if not await is_admin(admin_id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    text = message.text.strip()
    
    # Парсим пользователя
    target_id = None
    if text.startswith('@'):
        username = text[1:]
        user = await get_user_by_username(username)
        if user:
            target_id = user['user_id']
    else:
        try:
            target_id = int(text)
        except ValueError:
            await message.answer("❌ Неверный формат!")
            return
    
    if not target_id:
        await message.answer("❌ Пользователь не найден!")
        return
    
    # Нельзя банить админов и владельцев
    target_role = await get_user_role(target_id)
    if target_role in ['админ', 'владелец']:
        await message.answer("❌ Нельзя забанить админа или владельца!")
        await state.clear()
        return
    
    await state.update_data(target_id=target_id)
    
    await message.answer(
        "📝 Напишите причину бана:",
        reply_markup=get_back_button("back_to_admin")
    )
    await state.set_state(BanStates.waiting_for_reason)

@router.message(BanStates.waiting_for_reason)
async def admin_ban_reason(message: Message, state: FSMContext):
    """Обрабатывает причину бана и банит"""
    admin_id = message.from_user.id
    
    if not await is_admin(admin_id):
        await message.answer("❌ У вас нет доступа!")
        return
    
    data = await state.get_data()
    target_id = data.get('target_id')
    reason = message.text
    
    # Баним
    from database import DB_PATH
    import aiosqlite
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            'UPDATE users SET is_banned = 1 WHERE user_id = ?',
            (target_id,)
        )
        await db.commit()
    
    # Отправляем пользователю
    try:
        await message.bot.send_message(
            chat_id=target_id,
            text=(
                f"🔨 <b>ВЫ ЗАБАНЕНЫ!</b>\n\n"
                f"Причина: {reason}\n"
                f"Админ: @{message.from_user.username}\n\n"
                f"Для разблокировки обратитесь к администрации.",
                parse_mode="HTML"
            )
        )
    except Exception as e:
        print(f"Не удалось отправить сообщение пользователю {target_id}: {e}")
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    target_user = await get_user(target_id)
    await logger.log_ban(
        admin=message.from_user,
        user=types.User(id=target_id, username=target_user.get('username'), full_name=target_user.get('full_name')),
        reason=reason
    )
    
    await message.answer(
        f"✅ Пользователь @{target_user.get('username', target_id)} забанен!\n"
        f"Причина: {reason}",
        reply_markup=await get_admin_panel(admin_id)
    )
    await state.clear()

# ============ РАЗБАН ============

@router.callback_query(F.data == "admin_unban")
async def admin_unban_start(call: CallbackQuery, state: FSMContext):
    """Начинает процесс разбана"""
    user_id = call.from_user.id
    
    if not await is_admin(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "🔓 <b>Разбан пользователя</b>\n\n"
        "Отправьте ID пользователя или @username:",
        reply_markup=get_back_button("back_to_admin"),
        parse_mode="HTML"
    )
    await state.set_state(BanStates.waiting_for_user)
    await call.answer()

# ============ INFO КАНАЛ ============

@router.callback_query(F.data == "admin_info_channel")
async def admin_info_channel(call: CallbackQuery):
    """Отправляет ссылку на Info канал"""
    await call.message.edit_text(
        f"📢 <b>Info канал</b>\n\n"
        f"Ссылка: {config.INFO_CHANNEL_LINK}",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton("📢 Перейти в Info", url=config.INFO_CHANNEL_LINK)],
                [InlineKeyboardButton("🔙 Назад", callback_data="back_to_admin")]
            ]
        ),
        parse_mode="HTML"
    )
    await call.answer()

# ============ НАЗАД ============

@router.callback_query(F.data == "back_to_admin")
async def back_to_admin(call: CallbackQuery):
    """Возврат в админ панель"""
    user_id = call.from_user.id
    
    if not await is_admin(user_id):
        await call.answer("❌ У вас нет доступа!", show_alert=True)
        return
    
    await call.message.edit_text(
        "⚙️ <b>Админ панель</b>\n\n"
        "Выберите действие:",
        reply_markup=await get_admin_panel(user_id),
        parse_mode="HTML"
    )
    await call.answer()

@router.callback_query(F.data == "admin_apps_back")
async def admin_apps_back(call: CallbackQuery):
    """Возврат к списку заявок"""
    await admin_applications(call)