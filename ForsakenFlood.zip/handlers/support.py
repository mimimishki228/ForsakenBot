# bot/handlers/support.py
from aiogram import Router, F, types
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import get_user_role, get_all_admins, is_banned
from keyboards import get_flood_menu, get_back_button, get_cancel_button
from utils.logger import Logger
from config import config

router = Router()

# ============ FSM ДЛЯ ПОДДЕРЖКИ ============

class SupportStates(StatesGroup):
    waiting_for_message = State()

# ============ ПОДДЕРЖКА ============

@router.callback_query(F.data == "support")
async def support_start(call: CallbackQuery, state: FSMContext):
    """Начинает обращение в поддержку"""
    user_id = call.from_user.id
    
    if await is_banned(user_id):
        await call.answer("🚫 Вы забанены!", show_alert=True)
        return
    
    await call.message.edit_text(
        "🆘 <b>Поддержка</b>\n\n"
        "Напишите ваше сообщение.\n"
        "Администраторы ответят вам.\n\n"
        "Для отмены нажмите кнопку ниже.",
        reply_markup=get_cancel_button(),
        parse_mode="HTML"
    )
    
    await state.set_state(SupportStates.waiting_for_message)
    await call.answer()

@router.message(SupportStates.waiting_for_message)
async def support_send_message(message: Message, state: FSMContext):
    """Отправляет сообщение в поддержку админам"""
    user_id = message.from_user.id
    user_text = message.text
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    await logger.log_support_request(message.from_user, user_text)
    
    # Отправляем админам
    admins = await get_all_admins()
    owner_ids = config.OWNER_IDS
    
    sent_count = 0
    for admin in admins:
        if admin['user_id'] in owner_ids or admin['role'] in ['админ', 'владелец']:
            try:
                await message.bot.send_message(
                    chat_id=admin['user_id'],
                    text=(
                        f"🆘 <b>НОВОЕ ОБРАЩЕНИЕ В ПОДДЕРЖКУ!</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━\n\n"
                        f"👤 От: @{message.from_user.username} (ID: {user_id})\n"
                        f"📝 Сообщение:\n{user_text}\n\n"
                        f"Чтобы ответить, просто напишите в ответ на это сообщение."
                    ),
                    parse_mode="HTML"
                )
                sent_count += 1
            except Exception as e:
                print(f"Не удалось отправить админу {admin['user_id']}: {e}")
    
    if sent_count > 0:
        await message.answer(
            "✅ <b>Сообщение отправлено!</b>\n\n"
            "Администраторы ответят вам в ближайшее время.",
            reply_markup=get_back_button("back_to_flood"),
            parse_mode="HTML"
        )
    else:
        await message.answer(
            "❌ <b>Ошибка!</b>\n\n"
            "Не удалось отправить сообщение. Попробуйте позже.",
            reply_markup=get_back_button("back_to_flood"),
            parse_mode="HTML"
        )
    
    await state.clear()

# ============ ОТВЕТ АДМИНА В ПОДДЕРЖКУ ============

@router.message()
async def handle_support_admin_reply(message: Message):
    """Обрабатывает ответы админов на сообщения в поддержке"""
    admin_id = message.from_user.id
    
    # Проверяем, что это админ
    role = await get_user_role(admin_id)
    if role not in ['админ', 'владелец']:
        return
    
    # Проверяем, что это ответ на сообщение бота
    if not message.reply_to_message:
        return
    
    if message.reply_to_message.from_user.id != message.bot.id:
        return
    
    # Проверяем, что это сообщение из поддержки
    original_text = message.reply_to_message.text
    if "ОБРАЩЕНИЕ В ПОДДЕРЖКУ" not in original_text:
        return
    
    # Ищем ID пользователя
    import re
    match = re.search(r'ID: (\d+)', original_text)
    if not match:
        await message.answer("❌ Не удалось найти пользователя!")
        return
    
    user_id = int(match.group(1))
    
    # Отправляем ответ пользователю
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text=(
                f"📩 <b>Ответ от администрации:</b>\n\n"
                f"{message.text}\n\n"
                f"━━━━━━━━━━━━━━━━━━━\n"
                f"✉️ Вы можете продолжить диалог, написав в поддержку снова."
            ),
            parse_mode="HTML"
        )
        
        # Логируем
        logger: Logger = message.bot.data.get('logger')
        await logger.log_support_response(
            admin=message.from_user,
            user=types.User(id=user_id, username=None, full_name=None),
            response=message.text
        )
        
        await message.answer(
            f"✅ <b>Ответ отправлен!</b>\n"
            f"👤 Пользователю: ID {user_id}",
            parse_mode="HTML"
        )
        
    except Exception as e:
        await message.answer(f"❌ Не удалось отправить сообщение: {e}")