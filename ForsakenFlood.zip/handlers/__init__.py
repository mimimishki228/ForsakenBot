# bot/handlers/__init__.py
# Все обработчики команд и callback'ов