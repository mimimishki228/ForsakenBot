# bot/handlers/rest.py
import asyncio
from datetime import datetime, timedelta
from aiogram import Router, F, types
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from database import (
    get_user, get_user_role, create_application,
    get_application, update_application_status,
    create_rest, get_active_rests, is_banned,
    get_all_admins, update_user_role
)
from keyboards import get_flood_menu, get_back_button, get_cancel_button
from utils.info_manager import InfoManager
from utils.logger import Logger
from config import config

router = Router()

# ============ FSM ДЛЯ РЕСТА ============

class RestApplicationStates(StatesGroup):
    waiting_for_days = State()
    waiting_for_reason = State()
    waiting_for_confirm = State()

# ============ ЗАЯВКА НА РЕСТ ============

@router.callback_query(F.data == "rest_apply")
async def rest_apply(call: CallbackQuery, state: FSMContext):
    """Начинает процесс подачи заявки на рест"""
    user_id = call.from_user.id
    
    # Проверяем бан
    if await is_banned(user_id):
        await call.answer("🚫 Вы забанены!", show_alert=True)
        return
    
    # Проверяем, не на ресте ли уже
    user = await get_user(user_id)
    if user and user.get('rest_until'):
        rest_until = datetime.fromisoformat(user['rest_until'])
        if rest_until > datetime.now():
            days_left = (rest_until - datetime.now()).days
            await call.answer(f"⏰ Вы уже на ресте! Осталось {days_left} дней.", show_alert=True)
            return
    
    await call.message.edit_text(
        "⏰ <b>Заявка на рест</b>\n\n"
        "Заполните заявку на отдых.\n"
        "Отвечайте на вопросы.\n\n"
        "Для отмены нажмите кнопку ниже.",
        reply_markup=get_cancel_button(),
        parse_mode="HTML"
    )
    
    await call.message.answer(
        "📝 <b>Вопрос 1:</b>\n"
        "На сколько дней вы хотите уйти на рест? (Введите число)",
        parse_mode="HTML"
    )
    
    await state.set_state(RestApplicationStates.waiting_for_days)
    await call.answer()

@router.message(RestApplicationStates.waiting_for_days)
async def process_rest_days(message: Message, state: FSMContext):
    """Обрабатывает количество дней"""
    if not message.text.isdigit():
        await message.answer("❌ Введите число!")
        return
    
    days = int(message.text)
    if days < 1 or days > 30:
        await message.answer("❌ Количество дней должно быть от 1 до 30!")
        return
    
    await state.update_data(days=days)
    
    await message.answer(
        "📝 <b>Вопрос 2:</b>\n"
        "Причина реста:",
        parse_mode="HTML"
    )
    
    await state.set_state(RestApplicationStates.waiting_for_reason)

@router.message(RestApplicationStates.waiting_for_reason)
async def process_rest_reason(message: Message, state: FSMContext):
    """Обрабатывает причину"""
    await state.update_data(reason=message.text)
    
    data = await state.get_data()
    days = data.get('days')
    reason = data.get('reason')
    
    # Показываем подтверждение
    text = (
        "📋 <b>Проверьте заявку на рест:</b>\n\n"
        f"⏰ Дней: {days}\n"
        f"❓ Причина: {reason}\n\n"
        "Все верно?"
    )
    
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("✅ Да", callback_data="rest_confirm"),
                InlineKeyboardButton("❌ Нет, заново", callback_data="rest_restart")
            ]
        ]
    )
    
    await message.answer(text, reply_markup=keyboard, parse_mode="HTML")
    await state.set_state(RestApplicationStates.waiting_for_confirm)
    await state.update_data(form_data={'days': days, 'reason': reason})

@router.callback_query(F.data == "rest_confirm")
async def rest_confirm(call: CallbackQuery, state: FSMContext):
    """Подтверждение заявки на рест"""
    user_id = call.from_user.id
    data = await state.get_data()
    form_data = data.get('form_data')
    
    if not form_data:
        await call.answer("❌ Ошибка! Попробуйте заново.", show_alert=True)
        await state.clear()
        return
    
    # Создаем заявку в БД
    app_id = await create_application(user_id, 'rest', form_data)
    
    # Логируем
    logger: Logger = call.bot.data.get('logger')
    await logger.log_rest_application(call.from_user, form_data['days'])
    
    # Отправляем уведомление админам
    await notify_admins_about_rest(call.bot, app_id, form_data, call.from_user)
    
    await call.message.edit_text(
        "✅ <b>Заявка на рест отправлена!</b>\n\n"
        "Ожидайте ответа админов.",
        reply_markup=get_back_button("back_to_flood"),
        parse_mode="HTML"
    )
    await state.clear()
    await call.answer()

@router.callback_query(F.data == "rest_restart")
async def rest_restart(call: CallbackQuery, state: FSMContext):
    """Перезапуск анкеты"""
    await state.clear()
    await call.message.edit_text(
        "🔄 Начинаем заново...",
        reply_markup=get_back_button("back_to_flood")
    )
    await call.answer()

# ============ УВЕДОМЛЕНИЕ АДМИНОВ ============

async def notify_admins_about_rest(bot, app_id: int, form_data: dict, user: types.User):
    """Отправляет уведомление админам о новой заявке на рест"""
    
    text = (
        f"⏰ <b>НОВАЯ ЗАЯВКА НА РЕСТ!</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n\n"
        f"🆔 Заявка #<b>{app_id}</b>\n"
        f"👤 От: @{user.username} (ID: {user.id})\n\n"
        f"<b>Данные:</b>\n"
        f"⏰ Дней: {form_data.get('days')}\n"
        f"❓ Причина: {form_data.get('reason')}\n\n"
        f"Чтобы ответить, напишите под этим сообщением:\n"
        f"<code>Принять,14</code> или <code>Отклонено</code>"
    )
    
    admins = await get_all_admins()
    owner_ids = config.OWNER_IDS
    
    for admin in admins:
        if admin['user_id'] in owner_ids or admin['role'] in ['админ', 'владелец']:
            try:
                await bot.send_message(
                    chat_id=admin['user_id'],
                    text=text,
                    parse_mode="HTML"
                )
            except Exception as e:
                print(f"Не удалось отправить админу {admin['user_id']}: {e}")

# ============ ОБРАБОТКА ОТВЕТОВ АДМИНОВ ============

@router.message()
async def handle_rest_admin_reply(message: Message):
    """Обрабатывает ответы админов на заявки на рест"""
    user_id = message.from_user.id
    
    role = await get_user_role(user_id)
    if role not in ['админ', 'владелец']:
        return
    
    if not message.reply_to_message:
        return
    
    if message.reply_to_message.from_user.id != message.bot.id:
        return
    
    original_text = message.reply_to_message.text
    if "ЗАЯВКА НА РЕСТ" not in original_text:
        return
    
    import re
    match = re.search(r'#(\d+)', original_text)
    if not match:
        return
    
    app_id = int(match.group(1))
    
    application = await get_application(app_id)
    if not application or application['status'] != 'pending' or application['type'] != 'rest':
        await message.answer("❌ Заявка уже обработана!")
        return
    
    text = message.text.strip()
    
    if text.lower().startswith('принять'):
        parts = text.split(',')
        if len(parts) < 2:
            await message.answer(
                "❌ Неверный формат!\n"
                "Используйте: <code>Принять,14</code>",
                parse_mode="HTML"
            )
            return
        
        days = parts[1].strip()
        if not days.isdigit():
            await message.answer("❌ Введите число дней!")
            return
        
        await accept_rest_application(app_id, user_id, int(days), message)
        
    elif text.lower() == 'отклонено':
        await reject_rest_application(app_id, user_id, message)
    else:
        await message.answer(
            "❌ Неверная команда!\n"
            "Используйте: <code>Принять,14</code> или <code>Отклонено</code>",
            parse_mode="HTML"
        )

# ============ ПРИНЯТИЕ РЕСТА ============

async def accept_rest_application(app_id: int, admin_id: int, days: int, message: Message):
    """Принимает заявку на рест"""
    application = await get_application(app_id)
    if not application:
        return
    
    user_id = application['user_id']
    
    # Обновляем статус заявки
    await update_application_status(app_id, 'accepted', admin_id, f'Принят на рест на {days} дней')
    
    # Создаем рест
    await create_rest(user_id, days)
    
    # Отправляем пользователю
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text=(
                f"✅ <b>Ваш рест утвержден!</b>\n\n"
                f"⏰ Дней: {days}\n"
                f"📅 Дата окончания: {(datetime.now() + timedelta(days=days)).strftime('%d.%m.%Y')}\n\n"
                f"Отдыхайте! 🌿"
            ),
            parse_mode="HTML"
        )
    except Exception as e:
        print(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
    
    # Обновляем Info канал
    info_manager: InfoManager = message.bot.data.get('info_manager')
    await info_manager.update_rests()
    
    # Логируем
    logger: Logger = message.bot.data.get('logger')
    user = await get_user(user_id)
    admin_user = await get_user(admin_id)
    await logger.log_rest_accept(
        user=types.User(id=user_id, username=user.get('username'), full_name=user.get('full_name')),
        admin=types.User(id=admin_id, username=admin_user.get('username'), full_name=admin_user.get('full_name')),
        days=days
    )
    
    await message.answer(
        f"✅ Заявка на рест #<b>{app_id}</b> принята!\n"
        f"⏰ Дней: {days}\n"
        f"👤 Пользователь: @{user.get('username', user_id)}",
        parse_mode="HTML"
    )

# ============ ОТКЛОНЕНИЕ РЕСТА ============

async def reject_rest_application(app_id: int, admin_id: int, message: Message):
    """Отклоняет заявку на рест"""
    application = await get_application(app_id)
    if not application:
        return
    
    user_id = application['user_id']
    
    await update_application_status(app_id, 'rejected', admin_id, 'Отклонено')
    
    try:
        await message.bot.send_message(
            chat_id=user_id,
            text="❌ <b>Ваша заявка на рест отклонена!</b>",
            parse_mode="HTML"
        )
    except Exception as e:
        print(f"Не удалось отправить сообщение пользователю {user_id}: {e}")
    
    await message.answer(f"❌ Заявка на рест #<b>{app_id}</b> отклонена!", parse_mode="HTML")