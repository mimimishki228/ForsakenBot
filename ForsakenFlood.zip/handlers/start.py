# bot/handlers/start.py
from aiogram import Router, types
from aiogram.filters import Command
from database import create_user, is_banned
from keyboards import get_main_menu

router = Router()

@router.message(Command("start"))
async def cmd_start(message: types.Message):
    user = message.from_user
    
    await create_user(user.id, user.username, user.full_name)
    
    if await is_banned(user.id):
        await message.answer("🚫 Вы забанены!")
        return
    
    await message.answer(
        f"👋 Привет, {user.full_name}!\n\n"
        f"Выберите действие:",
        reply_markup=await get_main_menu(user.id)
    )