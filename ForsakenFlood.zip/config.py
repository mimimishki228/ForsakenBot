# bot/config.py
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # ============ ТОКЕН БОТА ============
    BOT_TOKEN = os.getenv('8643217867:AAFjYgQtQSV-mH6v6oUYhP2MfEFweqqdlm4')
    
    # ============ ВЛАДЕЛЬЦЫ ============
    OWNER_IDS = [int(x) for x in os.getenv('6116641075,8894979329', '').split(',') if x]
    
    # ============ КАНАЛЫ И ГРУППЫ ============
    
    # Канал с информацией (https://t.me/Infopopalol)
    INFO_CHANNEL_LINK = 'https://t.me/Infopopalol'
    INFO_CHANNEL_ID = -1003838658080  # ID канала (через @getmyid_bot)
    
    # Группа для флуда (куда кидать ссылку при принятии)
    FLOOD_GROUP_LINK = 'https://t.me/+IH79U8nJGXA1NDRi'
    FLOOD_GROUP_ID = -1003773588202  # ID группы
    
    # Канал для стаффа (инфо для админов)
    STAFF_CHANNEL_LINK = 'https://t.me/+5oG3cVk088RkMDQy'
    STAFF_CHANNEL_ID = -1004349007657
    
    # Канал для логов (только владельцы)
    LOGS_CHANNEL_ID = -1004348515952
    
    # ============ ID СООБЩЕНИЙ В INFO КАНАЛЕ ============
    # (обновляются автоматически, можно оставить None)
    INFO_ROLES_MSG_ID = None      # Сообщение с ролями флуда
    INFO_STAFF_MSG_ID = None      # Сообщение со стаффом
    INFO_REST_MSG_ID = None       # Сообщение с рестами
    INFO_STATUS_MSG_ID = None     # Сообщение со статусом набора
    
    # ============ НАСТРОЙКИ АНТИ-СПАМА ============
    SPAM_LIMIT = 5                # Максимум сообщений
    SPAM_WINDOW = 5               # За сколько секунд
    SPAM_BLOCK_TIME = 60          # Блокировка на секунд
    
    # ============ ПУТИ ============
    DATABASE_PATH = 'data.db'

config = Config()