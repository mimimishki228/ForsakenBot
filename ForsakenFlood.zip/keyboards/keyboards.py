# bot/keyboards.py
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from typing import List, Optional
from database import get_user_role, is_flood_open, is_admin, is_owner

# ============ ГЛАВНАЯ КЛАВИАТУРА ============

async def get_main_menu(user_id: int) -> InlineKeyboardMarkup:
    """Главное меню с учетом роли пользователя"""
    role = await get_user_role(user_id)
    
    buttons = [
        [InlineKeyboardButton("🌊 Flood", callback_data="menu_flood")],
        [InlineKeyboardButton("ℹ️ Info", callback_data="menu_info")]
    ]
    
    # Кнопка админ панели (только для админов и владельцев)
    if role in ['админ', 'владелец']:
        buttons.append([InlineKeyboardButton("⚙️ Админ панель", callback_data="menu_admin")])
    
    # Кнопка панели владельца (только для владельцев)
    if role == 'владелец':
        buttons.append([InlineKeyboardButton("👑 Панель владельца", callback_data="menu_owner")])
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ============ МЕНЮ FLOOD ============

async def get_flood_menu(user_id: int) -> InlineKeyboardMarkup:
    """Меню раздела Flood"""
    buttons = [
        [InlineKeyboardButton("📝 Подать заявку во флуд", callback_data="flood_apply")],
        [InlineKeyboardButton("👔 Заявка в стафф", callback_data="staff_apply")],
        [InlineKeyboardButton("⏰ Заявка на рест", callback_data="rest_apply")],
        [InlineKeyboardButton("🆘 Поддержка", callback_data="support")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ============ МЕНЮ ЗАЯВОК ДЛЯ АДМИНОВ ============

def get_applications_menu(app_type: str = None) -> InlineKeyboardMarkup:
    """Меню просмотра заявок для админов"""
    buttons = []
    
    if app_type:
        buttons.append([InlineKeyboardButton("📋 Все заявки", callback_data="admin_apps_all")])
    
    if app_type != 'flood':
        buttons.append([InlineKeyboardButton("🌊 Заявки во флуд", callback_data="admin_apps_flood")])
    
    if app_type != 'staff':
        buttons.append([InlineKeyboardButton("👔 Заявки в стафф", callback_data="admin_apps_staff")])
    
    if app_type != 'rest':
        buttons.append([InlineKeyboardButton("⏰ Заявки на рест", callback_data="admin_apps_rest")])
    
    buttons.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_admin")])
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_application_action_buttons(app_id: int) -> InlineKeyboardMarkup:
    """Кнопки для действия над заявкой"""
    buttons = [
        [
            InlineKeyboardButton("✅ Принять", callback_data=f"app_accept_{app_id}"),
            InlineKeyboardButton("❌ Отклонить", callback_data=f"app_reject_{app_id}")
        ],
        [InlineKeyboardButton("🔙 Назад к списку", callback_data="admin_apps_back")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ============ АДМИН ПАНЕЛЬ ============

async def get_admin_panel(user_id: int) -> InlineKeyboardMarkup:
    """Панель администратора"""
    buttons = [
        [InlineKeyboardButton("📋 Заявки", callback_data="admin_apps_all")],
        [InlineKeyboardButton("📢 Info канал", callback_data="admin_info_channel")],
        [InlineKeyboardButton("🔒 Закрыть набор", callback_data="admin_close_flood")],
        [InlineKeyboardButton("🔓 Открыть набор", callback_data="admin_open_flood")],
        [InlineKeyboardButton("🔨 Забанить", callback_data="admin_ban")],
        [InlineKeyboardButton("🔓 Разбанить", callback_data="admin_unban")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ============ ПАНЕЛЬ ВЛАДЕЛЬЦА ============

async def get_owner_panel(user_id: int) -> InlineKeyboardMarkup:
    """Панель владельца"""
    buttons = [
        [InlineKeyboardButton("➕ Добавить админа", callback_data="owner_add_admin")],
        [InlineKeyboardButton("➖ Удалить админа", callback_data="owner_remove_admin")],
        [InlineKeyboardButton("⚙️ Конфиг", callback_data="owner_config")],
        [InlineKeyboardButton("💥 Уничтожить (снять админов)", callback_data="owner_destroy")],
        [InlineKeyboardButton("🗑️ Очистить Info канал", callback_data="owner_clear_info")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_config_menu() -> InlineKeyboardMarkup:
    """Меню конфигурации"""
    buttons = [
        [InlineKeyboardButton("📝 Конфиг ролей флуда", callback_data="config_flood_roles")],
        [InlineKeyboardButton("📝 Конфиг ролей стаффа", callback_data="config_staff_roles")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_owner")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ============ ВСПОМОГАТЕЛЬНЫЕ КЛАВИАТУРЫ ============

def get_back_button(callback: str = "back_to_main") -> InlineKeyboardMarkup:
    """Кнопка назад"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("🔙 Назад", callback_data=callback)]
        ]
    )

def get_cancel_button() -> InlineKeyboardMarkup:
    """Кнопка отмены"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("❌ Отмена", callback_data="cancel")]
        ]
    )

def get_flood_member_menu() -> InlineKeyboardMarkup:
    """Меню для участника флуда"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton("🌊 Flood", callback_data="flood_group_link")]
        ]
    )

# bot/keyboards.py (дополняем)

async def get_owner_panel(user_id: int) -> InlineKeyboardMarkup:
    """Панель владельца (обновленная)"""
    buttons = [
        [InlineKeyboardButton("➕ Добавить админа", callback_data="owner_add_admin")],
        [InlineKeyboardButton("➖ Удалить админа", callback_data="owner_remove_admin")],
        [InlineKeyboardButton("🗑️ Удалить роль", callback_data="owner_remove_role")],  # НОВАЯ
        [InlineKeyboardButton("⚙️ Конфиг", callback_data="owner_config")],
        [InlineKeyboardButton("💥 Уничтожить (снять админов)", callback_data="owner_destroy")],
        [InlineKeyboardButton("🗑️ Очистить Info канал", callback_data="owner_clear_info")],
        [InlineKeyboardButton("🔙 Назад", callback_data="back_to_main")]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

# ============ МЕНЮ ВЫБОРА РОЛИ ДЛЯ УДАЛЕНИЯ ============

async def get_remove_role_menu(role_type: str) -> InlineKeyboardMarkup:
    """
    Меню выбора роли для удаления
    role_type: 'flood' или 'staff'
    """
    from database import get_flood_roles, get_staff_roles
    
    buttons = []
    
    if role_type == 'flood':
        roles = await get_flood_roles()
        for role in roles:
            buttons.append([
                InlineKeyboardButton(f"❌ {role}", callback_data=f"remove_flood_role_{role}")
            ])
    else:
        roles = await get_staff_roles()
        for role in roles:
            buttons.append([
                InlineKeyboardButton(f"❌ {role}", callback_data=f"remove_staff_role_{role}")
            ])
    
    buttons.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_owner")])
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)

async def get_remove_admin_menu() -> InlineKeyboardMarkup:
    """Меню выбора админа для удаления"""
    from database import get_all_admins
    
    admins = await get_all_admins()
    buttons = []
    
    for admin in admins:
        username = admin.get('username', f"ID:{admin['user_id']}")
        buttons.append([
            InlineKeyboardButton(f"❌ @{username}", callback_data=f"remove_admin_{admin['user_id']}")
        ])
    
    buttons.append([InlineKeyboardButton("🔙 Назад", callback_data="back_to_owner")])
    
    return InlineKeyboardMarkup(inline_keyboard=buttons)