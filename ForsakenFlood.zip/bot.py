import asyncio

from aiogram import Bot, Dispatcher

from loader import bot

from handlers.start import router as start_router

from handlers.panel import router as panel_router

from handlers.admin_messages import router as admin_messages_router

from handlers.applications import router as applications_router

dp = Dispatcher()


dp.include_router(start_router)
dp.include_router(panel_router)
dp.include_router(admin_messages_router)
dp.include_router(applications_router)

async def main():

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())